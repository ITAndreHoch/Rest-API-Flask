#!/bin/bash
#
docker-compose up -d
#
#
echo "MySQL init process in progress..."
sleep 15
echo "Mysql init proccess done."
echo ""
echo "Crating table and load data into it..."
#
# Exectue mysql script - create table "titanic_tbl"
mysql -h 0.0.0.0 -u titanic_user -ptitanic_password < /root/mysql/titanic_table.sql
#
#
# Parsing original file titanic.csv - escape single quote (apostrophe)
sed "s/'/\\\'/g" /root/mysql/titanic.csv | sed 's/\\/\\\\/g' > titanic_parsed.csv
#
#
# Load data into table titanic_tbl from parsed titanic.csv
IFS=,
while read column1 column2 column3 column4 column5 column6 column7 column8
      do
        echo "INSERT INTO titanic_tbl (survived,passengerClass,name,sex,age,siblingsOrSpousesAboard,parentsOrChildrenAboard,fare) VALUES ('$column1', '$column2', '$column3', '$column4', '$column5', '$column6', '$column7', '$column8');"

done < /root/mysql/titanic_parsed.csv | mysql -h 0.0.0.0 -u titanic_user -ptitanic_password titanic;
