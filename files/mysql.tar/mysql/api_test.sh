echo "API GET ONE PERSON:"
curl -i -H "Accept: application/json" -H "Content-Type: application/json" -X GET http://localhost:5000/people/1
echo "-------------------"
#
echo "API DELETE ONE PERSON:"
curl -i -X DELETE http://192.168.40.10:5000/people/5
echo "-------------------"
#
echo "API POST:"
curl -d '{ "survived": true, "passengerClass": 3, "name": "Mr. Owen Harris Braund", "sex": "male", "age": 22, "siblingsOrSpousesAboard": 1, "parentsOrChildrenAboard":0, "fare":7.25}' -H "Content-Type: application/json" -X POST http://localhost:5000/people
echo "-------------------"
#
echo "API PUT:"
curl -d '{ "survived": true, "passengerClass": 3, "name": "Mr. Owen Harris Braund", "sex": "male", "age": 22, "siblingsOrSpousesAboard": 1, "parentsOrChildrenAboard":0, "fare":700.25}' -H "Content-Type: application/json" -X PUT http://localhost:5000/people/50
echo "-------------------"
#
echo "API GET ALL:"
curl -i -H "Accept: application/json" -H "Content-Type: application/json" -X GET http://localhost:5000/people
echo "-------------------"
#
