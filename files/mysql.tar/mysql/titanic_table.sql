use titanic;
CREATE TABLE `titanic_tbl` (
  `uuid` INT PRIMARY KEY  NOT NULL AUTO_INCREMENT,
  `survived` BOOLEAN NOT NULL,
  `passengerClass` INT(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sex` ENUM('male','female','other') NOT NULL,
  `age` INT(3) NOT NULL,
   `siblingsOrSpousesAboard` INT(2) NOT NULL,
   `parentsOrChildrenAboard` INT(2) NOT NULL,
   `fare` FLOAT NOT NULL
);
